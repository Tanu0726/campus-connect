// src/pages/Login.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleLogin = (e) => {
    e.preventDefault();

    if (!formData.email || !formData.password) {
      alert("Please fill all fields.");
      return;
    }

    setLoading(true);

    // Mock login logic
    setTimeout(() => {
      setLoading(false);

      if (
        formData.email === "admin@campus.com" &&
        formData.password === "admin"
      ) {
        alert("Welcome Admin!");
        navigate("/dashboard");
      } else if (
        formData.email === "user@campus.com" &&
        formData.password === "user"
      ) {
        alert("Login successful!");
        navigate("/profile");
      } else {
        alert("Invalid credentials");
      }
    }, 1000);
  };

  return (
    <div className="form-container">
      <h2>Login to Campus Connect</h2>
      <form onSubmit={handleLogin}>
        <input
          type="email"
          name="email"
          placeholder="Enter your email"
          onChange={handleChange}
          value={formData.email}
          required
        />
        <input
          type="password"
          name="password"
          placeholder="Enter your password"
          onChange={handleChange}
          value={formData.password}
          required
        />
        <button type="submit" disabled={loading}>
          {loading ? "Logging in..." : "Login"}
        </button>
      </form>

      <div style={{ marginTop: "1rem", color: "#6b7280", fontSize: "0.9rem" }}>
        <p>
          Don't have an account? <a href="/register">Register here</a>
        </p>
      </div>
    </div>
  );
};

export default Login;
